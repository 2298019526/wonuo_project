<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"C:\xampp\htdocs\yuezhu_admin\public/../application/admin\view\user\userManagement.html";i:1579338393;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" name="viewport">
  <title>用户管理</title>

  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/modules/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/modules/ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/modules/fontawesome/web-fonts-with-css/css/fontawesome-all.min.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/css/demo.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/css/style.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/css/alerts.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/css/loading.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/modules/summernote/summernote-lite.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/modules/flag-icon-css/css/flag-icon.min.css">
  <style>
      .pagination .active{
        background-color: #574B90;
        color: #ffffff;
      }
      #tableData .detail{
          margin-right: 5px;
      }
  </style>
</head>

<body>
  <div id="app">
    <div class="main-wrapper">
      <!-- 头部导航 -->
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar">
        <form class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="ion ion-navicon-round"></i></a></li>
            <li><a href="#" data-toggle="search" class="nav-link nav-link-lg d-sm-none"><i class="ion ion-search"></i></a></li>
          </ul>
          <div class="search-element">
            <input class="form-control" type="search" placeholder="Search" aria-label="Search">
            <button class="btn" type="submit"><i class="ion ion-search"></i></button>
          </div>
        </form>
        <ul class="navbar-nav navbar-right">
          <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg">
            <i class="ion ion-android-person d-lg-none"></i>
            <div class="d-sm-none d-lg-inline-block">Hi, admin</div></a>
            <div class="dropdown-menu dropdown-menu-right">
              <a href="../login/login" class="dropdown-item has-icon">
                <i class="ion ion-log-out"></i> 注销
              </a>
            </div>
          </li>
        </ul>
      </nav>
      <!-- 头部导航 -->

      <!-- 左侧菜单 -->
      <div class="main-sidebar">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="../console/console">悦助后台管理系统</a>
          </div>
          <div class="sidebar-user">
            <div class="sidebar-user-picture">
              <img alt="image" src="/yuezhu_admin/public/static/dist/img/avatar/avatar-1.jpeg">
            </div>
            <div class="sidebar-user-details">
              <div class="user-name">admin</div>
              <div class="user-role">
                管理员
              </div>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">菜单栏</li>
            <li>
              <a href="../console/console"><i class="ion ion-speedometer"></i><span>控制台</span></a>
            </li>
            <li class="active">
              <a href="../user/userManagement"><i class="ion ion-ios-people"></i><span>用户管理</span></a>
            </li>
            <li>
              <a href="../reward/rewardManagement"><i class="ion ion-ios-list"></i><span>悬赏管理</span></a>
            </li>
            <li>
              <a href="#" class="has-dropdown"><i class="ion ion-ios-gear"></i><span>系统设置</span></a>
              <ul class="menu-dropdown">
                <li><a href="general.html"><i class="ion ion-ios-paper-outline"></i> 参数设置</a></li>
                <li><a href="components.html"><i class="ion ion-ios-list-outline"></i> 悬赏分类</a></li>
                <li><a href="buttons.html"><i class="ion ion-ios-pricetags-outline"></i> 搜索标签</a></li>
              </ul>
            </li>
          </ul>
          <div class="p-3 mt-4 mb-4">
            <a href="#" class="btn btn-danger btn-shadow btn-round has-icon has-icon-nofloat btn-block">
              <i class="ion ion-help-buoy"></i> <div>Go PRO!</div>
            </a>
          </div>
        </aside>
      </div>
      <!-- 左侧菜单 -->

      <!-- 主体内容 -->
      <div class="main-content">
        <section class="section">
            <h1 class="section-header">
                <div>人员管理</div>
            </h1>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                        <div class="float-right">
                            <div class="input-group">
                                <input id="searchValue" type="text" class="form-control" placeholder="请输入用户名">
                                <div class="input-group-btn">
                                <button id="searchUser" class="btn btn-secondary"><i class="ion ion-search"></i></button>
                                </div>
                            </div>
                        </div>
                        <h4>用户列表</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>用户名</th>
                                            <th>头像</th>
                                            <th>手机号</th>
                                            <th>积分</th>
                                            <th>发布悬赏</th>
                                            <th>接取悬赏</th>
                                            <th>操作</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tableData">
                                        
                                    </tbody>
                                </table>
                            </div>
                            <div class="card-footer">
                                <nav class="d-inline-block">
                                <ul class="pagination mb-0" id="pageContainer">
                                    
                                </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>  
            </div>
        </section>
      </div>
      <!-- 主体内容 -->

      <!-- 弹窗 -->
      <div class="popup-container" id="popupContainer">
        <div class="popup-main">
            <div class="popup-content">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>用户信息详情</h4>
                            <div class="popup-close" id="closePopup"><i class="ion ion-close-round"></i></div>
                        </div>
                        <div class="card-body">
                            <div class="card-line">
                                <div class="line-left">用户名：</div>
                                <div class="line-right" id="userName"></div>
                            </div>
                            <div class="card-line">
                                <div class="line-left">微信头像：</div>
                                <div class="line-right">
                                    <img id="userHead" alt="image" src="" class="rounded-circle" data-toggle="title" width="35">
                                </div>
                            </div>
                            <div class="card-line">
                                <div class="line-left">性别：</div>
                                <div class="line-right" id="userGender">
                                    <!-- <span class="user-gender">未知</span>
                                    <span class="user-gender">男 <i class="ion ion-male"></i></span>
                                    <span class="user-gender">女 <i class="ion ion-female"></i></span> -->
                                </div>
                            </div>
                            <div class="card-line">
                                <div class="line-left">联系电话：</div>
                                <div class="line-right" id="userPhone"></div>
                            </div>
                            <div class="card-line">
                                <div class="line-left">注册时间：</div>
                                <div class="line-right" id="userRegtime"></div>
                            </div>
                            <div class="card-line">
                                <div class="line-left">用户等级：</div>
                                <div class="line-right" id="userLevel">
                                    <!-- <div class="user-level gold">黄金</div>
                                    <div class="user-level silver">白银</div>
                                    <div class="user-level bronze">青铜</div> -->
                                </div>
                            </div>
                            <div class="card-line">
                                <div class="line-left">真实姓名：</div>
                                <div class="line-right" id="userRealName"></div>
                            </div>
                            <div class="card-line">
                                <div class="line-left">当前积分：</div>
                                <div class="line-right" id="userIntegral"></div>
                            </div>
                            <div class="card-line">
                                <div class="line-left">发布悬赏：</div>
                                <div class="line-right"><span id="releaseNumber"></span>次</div>
                            </div>
                            <div class="card-line">
                                <div class="line-left">接取悬赏：</div>
                                <div class="line-right"><span  id="receiveNumber"></span>次</div>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <!-- 弹窗 -->

      <!-- 确认弹窗 -->
      <div class="popup-container" id="confirmPopup">
        <div class="popup-mask"></div>
        <div class="popup-main">
            <div class="popup-content popup-confirm">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>提示</h4>
                                <div class="popup-close" id="closeDelPopup"><i class="ion ion-close-round"></i></div>
                            </div>
                            <div class="card-body">
                                <div class="delete-content">是否确认删除？删除后数据将无法恢复。</div>
                                <div class="delete-buttons">
                                    <a id="cancelDel" class="btn btn-sm">取消</a>
                                    <a data-userID="" id="confirmDel" class="btn btn-sm btn-primary">确认</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <!-- 确认弹窗 -->


      <!-- 加载动画 -->
      <div class="loading-container" id="loading">
        <div class="loading-mask"></div>
        <div class="loading-main">
            <div class="loading-content">
                <div class="loading-icon">
                    <i class="ion ion-load-c"></i>
                </div>
                <div class="loading-text">加载中...</div>
            </div>
        </div>
      </div>
      <!-- 加载动画 -->
    </div>
  </div>

  <script src="/yuezhu_admin/public/static/dist/modules/jquery.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/popper.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/tooltip.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/bootstrap/js/bootstrap.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/nicescroll/jquery.nicescroll.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/scroll-up-bar/dist/scroll-up-bar.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/js/sa-functions.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/chart.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/summernote/summernote-lite.js"></script>
  <script src="/yuezhu_admin/public/static/dist/js/scripts.js"></script>
  <script src="/yuezhu_admin/public/static/dist/js/custom.js"></script>
  <script src="/yuezhu_admin/public/static/dist/js/demo.js"></script>
  <script src="/yuezhu_admin/public/static/dist/js/alerts.js"></script>
  <script>
    var page = 1; //当前页码
    var pageSize = 10; //每页的数据条数
    var totalPage = 1; //总的页数
    var searchValue = ""; //搜索框值
    var userData = []; //用户列表数据

    getUserData();


    //搜索点击事件
    $("#searchUser").click(function(){
        searchValue = $("#searchValue").val();
        console.log(searchValue);
        getUserData();
    })

    //详情按钮点击事件
    $(document).on("click","#tableData .detail",function(){
        var user_id = $(this).attr("data-userID");
        var currentInfo = {};
        for(var i=0;i<userData.length;i++){
            if(userData[i].user_id==user_id){
                currentInfo = userData[i];
            }
        }
        $("#popupContainer").show();
        setUserDetail(currentInfo);
    })

    //关闭弹窗点击事件
    $("#closePopup").click(function(){
        $("#popupContainer").hide();
    })

    //删除按钮点击事件
    $(document).on("click","#tableData .delete",function(){
        var user_id = $(this).attr("data-userID");
        $("#confirmDel").attr("data-userID",user_id);
        $("#confirmPopup").show();
    })

    //确认弹窗关闭按钮
    $("#closeDelPopup").click(function(){
        $("#confirmPopup").hide();
    })

    //确认弹窗取消按钮
    $("#cancelDel").click(function(){
        $("#confirmPopup").hide();
    })
    
    //确认弹窗确认按钮
    $("#confirmDel").click(function(){
        var user_id = $(this).attr("data-userID");
        $("#confirmPopup").hide();
        $("#loading").show();
        $.ajax({
            url: "deleteUser",
            type: "POST",
            data: {
                user_id: user_id
            },
            complete: function(){
                $("#loading").hide();
            },
            success: function(res){
                console.log(res);
                if(res.code=='0'){
                    getUserData();
                }else{
                    alerts.show({
                        type: 'warning',
                        title: "提示",
                        content: res.msg,
                        direction: 2000
                    })
                }
            },
            error: function(){
                alert("获取数据失败！");
            }
        })

    })

    //上一页点击事件
    $(document).on("click", "#pageContainer #prevPage", function(){
        if($(this).hasClass("disabled")) return false;
        if(page==1) return false;
        page--;
        getUserData();
    })

    //页码点击事件
    $(document).on("click", "#pageContainer .page-number", function(){
        if($(this).hasClass("active")) return false;
        page = Number($(this).attr("data-page"));
        getUserData();
    })

    //下一页点击事件
    $(document).on("click", "#pageContainer #nextPage", function(){
        if($(this).hasClass("disabled")) return false;
        if(page==totalPage) return false;
        page++;
        getUserData();
    })

    function getUserData(){ //获取数据
        $("#loading").show();

        var upData = {
            page: page,
            pageSize: pageSize
        }
        if(searchValue.length>0){
            upData.searchValue = searchValue;
        }

        $.ajax({
            url: "getUserData",
            type: "POST",
            data: upData,
            complete: function(){
                $("#loading").hide();
            },
            success: function(res){
                console.log(res);
                if(res.code=='0'){
                    userData = res.data.list;
                    totalPage = res.data.total;
                    setTableData(res.data.list,res.data.total);
                }else{
                    alerts.show({
                        type: 'warning',
                        title: "提示",
                        content: res.msg,
                        direction: 2000
                    })
                }
            },
            error: function(){
                alert("获取数据失败！");
            }
        })
    }

    function setTableData(data,total){ //设置表格
        $("#tableData").empty();
        $("#pageContainer").empty();

        for(var i=0;i<data.length;i++){
            var line = `<tr>
                            <td>${data[i].user_name}</td>
                            <td>
                                <img alt="image" src="${data[i].user_head}" class="rounded-circle" data-toggle="title" title="${data[i].user_name}" width="35">
                            </td>
                            <td>${data[i].user_phone}</td>
                            <td>${data[i].integral_balance}</td>
                            <td>${data[i].release_number}</td>
                            <td>${data[i].receive_number}</td>
                            <td>
                                <a data-userID="${data[i].user_id}" class="detail btn btn-action btn-secondary btn-info">详情</a>
                                <a data-userID="${data[i].user_id}" class="delete btn btn-action btn-secondary btn-danger">删除</a>
                            </td>
                        </tr>`;
            $("#tableData").append(line);
            
        }

        for(var n=0; n<Number(total); n++){
            var html = '';
            if(n==0){
                if(page==1){
                    html += '<li id="prevPage" class="page-item disabled"><a class="page-link" tabindex="-1"><i class="ion ion-chevron-left"></i></a></li>';
                }else{
                    html += '<li id="prevPage" class="page-item"><a class="page-link" tabindex="-1"><i class="ion ion-chevron-left"></i></a></li>';
                }
            }
            var nowPage = n+1;
            if(page==nowPage){
                html += '<li class="page-item page-number active" data-page="'+nowPage+'"><a class="page-link">'+nowPage+'</a></li>';
            }else{
                html += '<li class="page-item page-number" data-page="'+nowPage+'"><a class="page-link">'+nowPage+'</a></li>';
            }
            if(nowPage==total){
                if(page==total){
                    html += '<li id="nextPage" class="page-item disabled"><a class="page-link"><i class="ion ion-chevron-right"></i></a></li>';
                }else{
                    html += '<li id="nextPage" class="page-item"><a class="page-link"><i class="ion ion-chevron-right"></i></a></li>';
                }
            }
            
            $("#pageContainer").append(html);
        }

    }


    function setUserDetail(info){
        //console.log(info);
        $("#userName").html(info.user_name);
        $("#userHead").attr("src",info.user_head);
        if(info.user_gender=='0'){
            $("#userGender").html('<span class="user-gender">未知</span>');
        }else if(info.user_gender=='1'){
            $("#userGender").html('<span class="user-gender">男 <i class="ion ion-male"></i></span>');
        }else if(info.user_gender=='2'){
            $("#userGender").html('<span class="user-gender">女 <i class="ion ion-female"></i></span>');                
        }
        $("#userPhone").html(info.user_phone);
        $("#userRegtime").html(info.user_regtime);
        if(info.user_level=='0'){
            $("#userLevel").html('<div class="user-level bronze">青铜</div>');
        }else if(info.user_level=='1'){
            $("#userLevel").html('<div class="user-level silver">白银</div>');
        }else if(info.user_level=='2'){
            $("#userLevel").html('<div class="user-level gold">黄金</div>');
        }
        $("#userRealName").html(info.real_name);
        $("#userIntegral").html(info.integral_balance);
        $("#releaseNumber").html(info.release_number);
        $("#receiveNumber").html(info.receive_number);

    }
  </script>
</body>
</html>