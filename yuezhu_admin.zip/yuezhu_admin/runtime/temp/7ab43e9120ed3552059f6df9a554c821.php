<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"C:\xampp\htdocs\yuezhu_admin\public/../application/admin\view\login\login.html";i:1579309880;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" name="viewport">
  <title>登录</title>

  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/modules/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/modules/ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/modules/fontawesome/web-fonts-with-css/css/fontawesome-all.min.css">

  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/css/demo.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/css/style.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/css/alerts.css">
</head>

<body>
  <div id="app">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
            <div class="login-brand">
              悦助后台管理系统
            </div>

            <div class="card card-primary">
              <div class="card-header"><h4>登录</h4></div>

              <div class="card-body">
                <div class="needs-validation" >
                  <div class="form-group">
                    <label for="user_name">用户名</label>
                    <input id="user_name" type="text" class="form-control" name="userName" tabindex="1" required autofocus>
                    <div class="invalid-feedback">
                      请填写你的用户名
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="password" class="d-block">密码
                      <div class="float-right">
                        <a href="forgot.html">
                          忘记密码？
                        </a>
                      </div>
                    </label>
                    <input id="password" type="password" class="form-control" name="password" tabindex="2" required>
                    <div class="invalid-feedback">
                      请填写你的密码
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="custom-control custom-checkbox">
                      <input type="checkbox" name="remember" class="custom-control-input" tabindex="3" id="remember-me">
                      <label class="custom-control-label" for="remember-me">记住我</label>
                    </div>
                  </div>

                  <div class="form-group">
                    <button type="button" class="btn btn-primary btn-block" tabindex="4" id="submit">
                      登录
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="simple-footer">
              版权 &copy; 悦助后台管理系统 2018
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <script src="/yuezhu_admin/public/static/dist/modules/jquery.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/popper.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/tooltip.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/bootstrap/js/bootstrap.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/nicescroll/jquery.nicescroll.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/moment.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/scroll-up-bar/dist/scroll-up-bar.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/js/sa-functions.js"></script>
  
  <script src="/yuezhu_admin/public/static/dist/js/scripts.js"></script>
  <script src="/yuezhu_admin/public/static/dist/js/custom.js"></script>
  <script src="/yuezhu_admin/public/static/dist/js/demo.js"></script>
  <script src="/yuezhu_admin/public/static/dist/js/alerts.js"></script>

  <script>
    //登录按钮点击事件
    $("#submit").click(function(){
      var userName = $("#user_name").val();
      var password = $("#password").val();

      $.ajax({
        type: "POST",
        url: 'loginCheck',
        data: {
          admin_name: userName,
          admin_pwd: password
        },
        success: function(res){
          console.log(res);
          if(res.code=='0'){
            alerts.show({
              title: "提示",
              content: "登录成功",
              direction: 1000,
              success: function(){
                window.location.href = "../console/console";
              }
            })
            
          }else{
            alerts.show({
              type: "danger",
              title: "提示",
              content: res.msg
            })
          }
        }
      })

    })
  
  </script>
</body>
</html> 