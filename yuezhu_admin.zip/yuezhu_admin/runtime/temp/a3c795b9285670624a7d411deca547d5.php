<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"C:\xampp\htdocs\yuezhu_admin\public/../application/admin\view\console\console.html";i:1579328812;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" name="viewport">
  <title>控制台</title>

  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/modules/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/modules/ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/modules/fontawesome/web-fonts-with-css/css/fontawesome-all.min.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/css/demo.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/css/style.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/css/alerts.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/modules/summernote/summernote-lite.css">
  <link rel="stylesheet" href="/yuezhu_admin/public/static/dist/modules/flag-icon-css/css/flag-icon.min.css">
</head>

<body>
  <div id="app">
    <div class="main-wrapper">
      <!-- 头部导航 -->
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar">
        <form class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="ion ion-navicon-round"></i></a></li>
            <li><a href="#" data-toggle="search" class="nav-link nav-link-lg d-sm-none"><i class="ion ion-search"></i></a></li>
          </ul>
          <div class="search-element">
            <input class="form-control" type="search" placeholder="Search" aria-label="Search">
            <button class="btn" type="submit"><i class="ion ion-search"></i></button>
          </div>
        </form>
        <ul class="navbar-nav navbar-right">
          <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg">
            <i class="ion ion-android-person d-lg-none"></i>
            <div class="d-sm-none d-lg-inline-block">Hi, admin</div></a>
            <div class="dropdown-menu dropdown-menu-right">
              <a href="../login/login" class="dropdown-item has-icon">
                <i class="ion ion-log-out"></i> 注销
              </a>
            </div>
          </li>
        </ul>
      </nav>
      <!-- 头部导航 -->

      <!-- 左侧菜单 -->
      <div class="main-sidebar">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="../console/console">悦助后台管理系统</a>
          </div>
          <div class="sidebar-user">
            <div class="sidebar-user-picture">
              <img alt="image" src="/yuezhu_admin/public/static/dist/img/avatar/avatar-1.jpeg">
            </div>
            <div class="sidebar-user-details">
              <div class="user-name">admin</div>
              <div class="user-role">
                管理员
              </div>
            </div>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">菜单栏</li>
            <li class="active">
              <a href="../console/console"><i class="ion ion-speedometer"></i><span>控制台</span></a>
            </li>
            <li>
              <a href="../user/userManagement"><i class="ion ion-ios-people"></i><span>用户管理</span></a>
            </li>
            <li>
              <a href="../reward/rewardManagement"><i class="ion ion-ios-list"></i><span>悬赏管理</span></a>
            </li>
            <li>
              <a href="#" class="has-dropdown"><i class="ion ion-ios-gear"></i><span>系统设置</span></a>
              <ul class="menu-dropdown">
                <li><a href="general.html"><i class="ion ion-ios-paper-outline"></i> 参数设置</a></li>
                <li><a href="components.html"><i class="ion ion-ios-list-outline"></i> 悬赏分类</a></li>
                <li><a href="buttons.html"><i class="ion ion-ios-pricetags-outline"></i> 搜索标签</a></li>
              </ul>
            </li>
          </ul>
          <div class="p-3 mt-4 mb-4">
            <a href="#" class="btn btn-danger btn-shadow btn-round has-icon has-icon-nofloat btn-block">
              <i class="ion ion-help-buoy"></i> <div>Go PRO!</div>
            </a>
          </div>
        </aside>
      </div>
      <!-- 左侧菜单 -->

      <!-- 主体内容 -->
      <div class="main-content">
        <section class="section">
          <h1 class="section-header">
            <div>控制台</div>
          </h1>
          <div class="row">
            <div class="col-lg-3 col-md-6 col-12">
              <a href="../user/userManagement" class="card card-sm-3">
                <div class="card-icon bg-primary">
                  <i class="ion ion-person"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>新增用户</h4>
                  </div>
                  <div class="card-body">
                    10
                  </div>
                </div>
              </a>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
              <a href="../reward/rewardManagement" class="card card-sm-3">
                <div class="card-icon bg-success">
                  <i class="ion ion-ios-paper-outline"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>新增悬赏</h4>
                  </div>
                  <div class="card-body">
                    15
                  </div>
                </div>
              </a>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
              <a href="../reward/rewardManagement" class="card card-sm-3">
                <div class="card-icon bg-warning">
                  <i class="ion ion-paper-airplane"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>完成悬赏</h4>
                  </div>
                  <div class="card-body">
                    8
                  </div>
                </div>
              </a>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
              <a href="../reward/rewardManagement" class="card card-sm-3">
                <div class="card-icon bg-danger">
                  <i class="ion ion-record"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>超时悬赏</h4>
                  </div>
                  <div class="card-body">
                    20
                  </div>
                </div>
              </a>
            </div>                  
          </div>
          <div class="row">
            <div class="col-lg-12 col-md-12 col-12 col-sm-12">
              <div class="card">
                <div class="card-header">
                  <div class="float-right">
                    <div class="btn-group">
                      <a href="#" class="btn active">本周</a>
                    </div>
                  </div>
                  <h4>统计</h4>
                </div>
                <div class="card-body">
                  <canvas id="myChart" height="158"></canvas>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
      <!-- 主体内容 -->
    </div>
  </div>

  <script src="/yuezhu_admin/public/static/dist/modules/jquery.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/popper.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/tooltip.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/bootstrap/js/bootstrap.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/nicescroll/jquery.nicescroll.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/scroll-up-bar/dist/scroll-up-bar.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/js/sa-functions.js"></script>
  
  <script src="/yuezhu_admin/public/static/dist/modules/chart.min.js"></script>
  <script src="/yuezhu_admin/public/static/dist/modules/summernote/summernote-lite.js"></script>
  <script>
    getStartDatt();

    function getStartDatt(){
      $.ajax({
        url: "getCountData",
        type: "POST",
        success: function(res){
          console.log(res);
          if(res.code=='0'){
            initChart(res.data.arr,res.data.countData);
          }else{
            alert(res.msg);
          }
        },
        error: function(){
          alert("获取数据失败！");
        }
      })
    }

    function initChart(xData,countData){
      var ctx = document.getElementById("myChart").getContext('2d');
      var myChart = new Chart(ctx, {
        type: 'line',
        data: {
            //折线图需要为每个数据点设置一标签。这是显示在X轴上。
            labels: xData,
            //数据集（y轴数据范围随数据集合中的data中的最大或最小数据而动态改变的）
            datasets: [
              {
                label: '新增人员',
                backgroundColor: "rgba(63,82,227,0.4)", //背景填充色
                borderColor: "#3F52E3", //路径颜色
                pointBackgroundColor: "#3F52E3", //数据点颜色
                pointBorderColor: "#fff", //数据点边框颜色
                data: countData.newUser //对应的值
              },{
                label: '新增悬赏',
                backgroundColor: "rgba(40,167,69,0.4)", //背景填充色
                borderColor: "#28a745", //路径颜色
                pointBackgroundColor: "#28a745", //数据点颜色
                pointBorderColor: "#fff", //数据点边框颜色
                data: countData.newRelease //对应的值
              },{
                label: '完成悬赏',
                backgroundColor: "rgba(255,193,7,0.4)", //背景填充色
                borderColor: "#ffc107", //路径颜色
                pointBackgroundColor: "#ffc107", //数据点颜色
                pointBorderColor: "#fff", //数据点边框颜色
                data: countData.finish //对应的值
              },{
                label: '超时悬赏',
                backgroundColor: "rgba(220,53,69,0.4)", //背景填充色
                borderColor: "#dc3545", //路径颜色
                pointBackgroundColor: "#dc3545", //数据点颜色
                pointBorderColor: "#fff", //数据点边框颜色
                data: countData.overTime //对应的值
              }
            ]
        },
        options: {
          legend: {
            display: false
          },
          scales: {
            xAxes: [{
              gridLines: {
                display: false
              }
            }]
          },
        }
      });
    }
  </script>
  <script src="/yuezhu_admin/public/static/dist/js/scripts.js"></script>
  <script src="/yuezhu_admin/public/static/dist/js/custom.js"></script>
  <script src="/yuezhu_admin/public/static/dist/js/demo.js"></script>
</body>
</html>