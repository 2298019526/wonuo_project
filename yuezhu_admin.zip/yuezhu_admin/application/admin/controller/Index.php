<?php
namespace app\admin\controller;

class Index
{
    public function index()
    {
        return '后台模块的主页';
    }
}
